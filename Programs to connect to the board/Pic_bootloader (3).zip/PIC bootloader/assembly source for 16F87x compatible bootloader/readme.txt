This directory contains legacy code.

The 16F87xA bootloader will work with both the 16F87xA and the 16F87x.

The 16F87x bootloader will *not* work with the 16F87xA.

