It is recommended that you build your own version of the bootloader rather than using the legacy .hex files.

The legacy .hex files are out of date; they are not synchronized to the latest version.